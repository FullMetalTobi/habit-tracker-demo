# Ü5 Verify v1: Gates, E2E, Beleg pro Kriterium

**Tag 2 · Donnerstag 19.11., vor dem Mittag · Zeitbox 60 Minuten**

## Ziel

Ihr baut die ersten drei Schichten von `/verify`: alle Gates inkl. E2E, ein Beleg aus Code und Test für jedes Akzeptanzkriterium, ein Bericht mit Verdict. Verify prüft und baut nicht. Befunde gehen zurück an `/code`.

**Done, wenn …**

- [ ] `.claude/skills/verify/SKILL.md` existiert, mit `disable-model-invocation: true` und der Regel „You check, you do not build“,
- [ ] der Skill alle Gates fährt, inkl. E2E (Weg B: `PORT=3110 E2E_PORT=3110 npm run test:e2e`), und Ergebnis, Testanzahl und Dauer festhält,
- [ ] der Skill für **jedes** Akzeptanzkriterium `met`, `partly met` oder `not met` mit Datei und Testname als Beleg festhält (ohne Test höchstens `partly met`),
- [ ] `/verify specs/<slug>.md` in einer neuen Session gelaufen ist und `specs/<slug>.verification.md` mit **Verdict: Pass** oder **Issues found** committet hat.

„Issues found“ ist ein gutes Ergebnis. Dann hat Verify seine Arbeit getan.

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen, Stand prüfen (`git log --oneline -3`, Gates einmal von Hand) |
| 5-25 | `verify`-Skill schreiben: Laden, Spec gegen Implementierung, Gates, Bericht |
| 25-30 | Dev-Server stoppen (`lsof -i :3110` muss leer sein), neue Session, `/verify specs/<slug>.md` |
| 30-48 | Lauf beobachten. Währenddessen im Raum den Bericht von `kurs/verify-rot` lesen (Hilfe 3) |
| 48-55 | Eigenen Bericht lesen: Stimmen die Belege? Ist „met“ wirklich belegt? |
| 55-60 | Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Weg A: euer Repo

1. Skill aus der Vorlage übernehmen:

   ```bash
   mkdir -p .claude/skills/verify
   cp ../rheinwerk-starter-skills/.claude/skills/verify/SKILL.md \
     .claude/skills/verify/SKILL.md
   grep -n ANPASSEN .claude/skills/verify/SKILL.md
   ```

2. Für v1 nur **Load, Spec against implementation, Gates, Report** behalten. Die Abschnitte „Fresh review“, „Browser walk“ und „Draft PR/MR“ löscht ihr vorerst, sie kommen in Ü6 und Ü7 zurück. Passt dazu die Verdict-Regel und die Berichts-Vorlage an (nur Kriterien und Gates).
3. Settings füllen: Basis-Branch, Gates. **Keine E2E-Tests?** Dann stehen nur die schnellen Gates drin, und der Bericht schreibt unter „Not verified“, was ein E2E-Test geprüft hätte. **E2E nur in der Pipeline?** Ebenso, und als Notiz für Ü7 (dort wartet Verify auf die Pipeline).
4. Committen, neue Session, `/verify specs/<slug>.md`.

## Weg B: Demo-Fork

1. Auf eurem Branch (`seminar/kategorien` bzw. `seminar/ab-ue5`) den Skill schreiben (Gerüst in Hilfe 2). Die drei Schichten:
   - **Gates:** `npm run lint`, `npm run typecheck`, `npm test`. Rot ist ein blockierender Befund. Nie einen roten Test so lange wiederholen, bis er zufällig grün ist.
   - **E2E:** der Befehl im Kasten. `PORT` ist der Port der App, `E2E_PORT` der, auf den Playwright wartet. Nie 3000 (Playwright-Default). Läuft schon ein Dev-Server auf 3110, nimmt Playwright den statt des Builds, also vorher stoppen.

     ```bash
     PORT=3110 E2E_PORT=3110 npm run test:e2e
     ```

   - **Beleg pro Kriterium:** für jedes AC und jede Must-Anforderung Code und Test finden. Ohne Test höchstens `partly met`. Scope Creep melden.
2. Committen und Port prüfen:

   ```bash
   git add .claude/skills/verify && git commit -m "feat(skills): add verify skill v1"
   lsof -i :3110 || echo "3110 frei"
   ```

3. Neue Session:

   ```text
   /verify specs/kategorien.md
   ```

4. Bericht lesen: `cat specs/kategorien.verification.md`, Commit prüfen: `git log --oneline -1`.

## Pro Tool

| Tool | Aufruf | Hinweis |
|---|---|---|
| Claude Code | `/verify specs/kategorien.md` | Die Allow-Liste aus Ü4 enthält den E2E-Befehl. Sonst den Prompt einmal bestätigen. |
| Codex | `$verify specs/kategorien.md` (nach `cp -R .claude/skills .agents/`) | E2E startet einen Browser und einen Server auf 3110. Scheitert das in der Sandbox, im Demo-Fork über `/permissions` Full Access. |
| Cursor | `/verify specs/kategorien.md` im Agent-Chat | Langer Terminal-Befehl: Wartet, bis der Agent die Ausgabe gelesen hat, nicht abbrechen. |
| Copilot | `/verify specs/kategorien.md` im Agent-Modus bzw. in der CLI | Wie Cursor. |

`disable-model-invocation: true` ist ein Claude-Code-Feld: Der Skill startet nur, wenn ihr ihn tippt. Andere Tools ignorieren es oder werten es eigen aus, siehe Doku eures Tools.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Warum ein eigener Skill und nicht einfach am Ende von `/code`? Wer gebaut hat, prüft gnädig. Verify startet in einer neuen Session und sieht nur Spec, Branch und Gates.
- „Met“ heißt: Es gibt Code **und** einen Test, der brechen würde, wenn das Kriterium bricht. „Der Code sieht richtig aus“ ist kein Beleg.
- Der Bericht liegt im Repo neben der Spec. In Ü7 hängt ihr ihn an den MR.

</details>

<details>
<summary>Hilfe 2: Gerüst zum Kopieren</summary>

````markdown
---
name: verify
description: Verify a branch against its spec, run the gates, write a report.
argument-hint: "[specs/<slug>.md]"
disable-model-invocation: true
---

# Verify

Verify the implementation of: **$ARGUMENTS**

You check, you do not build. Fix nothing here. Findings go to the report,
fixes go back to `/code`.

## Load
- Read the spec. Collect the diff:
  `git diff main...HEAD --stat`, `git log main..HEAD --oneline`.

## Spec against implementation
For every acceptance criterion and every Must requirement, find the code and the
test that prove it. Record `met`, `partly met` or `not met` with file and test name.
A criterion without a test is at most `partly met`. Flag scope creep.

## Gates
Run each, record result, test counts and duration:
<lint>, <typecheck>, <unit tests>, <e2e with a fixed free port, never 3000>
Stop a dev server on that port first. A red gate is a blocking finding.
Never rerun a failing test until it passes by luck.

## Report
Write `specs/<slug>.verification.md`:
  # Verification: <Title>
  Branch: <branch> @ <sha>  ·  Verdict: Pass | Issues found
  ## Acceptance criteria   | AC | Code + test | Result |
  ## Gates                 | Gate | Result | Duration |
  ## Not verified
Verdict is Pass only when every gate is green and every criterion is `met`.
Commit only the report: `docs(spec): add verification report for <slug>`.
````

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

Die drei Schichten einzeln, je als Diff zur Vorstufe:

```bash
F=.claude/skills/verify/SKILL.md
git show origin/stufe/04-verify-gates:$F
git diff origin/stufe/04-verify-gates origin/stufe/05-verify-e2e -- $F
git diff origin/stufe/05-verify-e2e origin/stufe/06-verify-spec-abgleich -- $F
```

Ein Bericht mit „Issues found“ (aus `kurs/verify-rot`, dazu im Bonus mehr):

```bash
git show origin/kurs/verify-rot:specs/kategorien.verification.md | head -60
```

Weg A: `.claude/skills/verify/SKILL.md` in der Vorlage, Abschnitte 1-3 und 6.

</details>

## Rückfall

Weg B: Skill v1 aus Stufe 6 holen und committen, dann weiter mit Ü6:

```bash
git checkout origin/stufe/06-verify-spec-abgleich -- .claude/skills/verify
git commit -m "feat(skills): add verify skill v1"
```

Codex danach spiegeln bzw. Copilot in VS Code, falls nötig (nur den Kasten für euer Tool):

```bash
# Codex
mkdir -p .agents && cp -R .claude/skills .agents/
```

```bash
# Copilot in VS Code
mkdir -p .github && cp -R .claude/skills .github/
```

Weg A: Minimum für Ü6 ist ein `verify`-Skill, der eure schnellen Gates fährt und einen Bericht schreibt. Den Abgleich mit den Kriterien ergänzt ihr, wenn Zeit ist.

## Bonus für Schnelle

**Findet euer Verify den eingebauten Fehler?** `kurs/verify-rot` enthält wieder den Leerzustand-Fehler aus Ü1 (Open-Tab bei aktivem Filter). Lasst euren eigenen Skill darauf los. Den Musterbericht löscht ihr vorher, sonst liest der Agent die Lösung ab.

Geht nur, wenn euer `verify` auf eurem Branch committet ist (Weg B, Schritt 2). Sonst testet ihr still den Muster-Skill aus `kurs/verify-rot`. Erst prüfen, nur bei `ok` weiter:

```bash
git cat-file -e HEAD:.claude/skills/verify/SKILL.md 2>/dev/null \
  && echo "ok" || echo "STOPP: erst euren verify-Skill committen"
```

```bash
B=$(git branch --show-current)
git switch --no-track -c seminar/verify-rot origin/kurs/verify-rot
git rm -rq .claude/skills/verify
git checkout "$B" -- .claude/skills/verify
git rm -q specs/kategorien.verification.md
git commit -m "chore: eigenen verify-Skill auf verify-rot testen"
```

Neue Session, `/verify specs/kategorien.md`. Erwartet: E2E rot (E4 in `e2e/specs/categories.spec.ts`), AC5 `not met`, Verdict „Issues found“. Vergleichen mit `git show origin/kurs/verify-rot:specs/kategorien.verification.md`. Zurück: `git switch "$B"`.

Weitere Ideen: Weg B Issue #2 verifizieren. Weg A: ein Kriterium absichtlich brechen und prüfen, ob Verify es merkt (danach `git checkout -- .`).

## Für den Debrief

Leitfrage: **Wer hat etwas Rotes gefunden? Was hat Verify übersehen?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): euer Verdict, der wichtigste Befund (oder „Pass, aber …“) und eine Frage.
- Im Plenum zeigen zwei Räume ihren Bericht. Der Kursleiter zeigt den Bericht von `kurs/verify-rot`.
