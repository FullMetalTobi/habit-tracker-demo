# Ü7 Draft-MR und Team-Plan

**Tag 2 · Donnerstag 19.11., zum Abschluss · Zeitbox 40 Minuten**

## Ziel

Ihr nehmt den Flow mit ins Team. Kern ist ein Team-Plan auf einer Seite: Worauf einigt ihr euch, bevor ihr mit Agenten arbeitet, und wie startet ihr? Nebenbei öffnet `/verify … --pr` einen Draft-PR bzw. Draft-MR, der auf das Ticket verweist.

**Done, wenn …**

- [ ] in eurer Kopie der [Team-Plan-Vorlage](team-plan-vorlage.md) (`team-plan.md`, siehe unten) die **Pflicht-Abschnitte** ausgefüllt sind: 1 Ticket-Standard, 2 Spec-Freigabe, 4 Wer prüft was, 7 Pilot mit drei Tickets, 8 Messgrößen, 10 Erster Schritt. Die übrigen Abschnitte (3, 5, 6, 9) sind optional bzw. für zu Hause,
- [ ] ihr „Mein erster Schritt am Montag“ in einem Satz formuliert habt.

**Wo ihr ausfüllt:** im Markdown, nicht im PDF. Nehmt `team-plan-vorlage.md` aus dem Markdown-Zip (`uebungsblaetter-markdown.zip`), speichert sie als `team-plan.md` lokal neben eurem Repo (oder im eigenen Repo, wenn er dort liegen soll) und füllt sie im Editor aus. Für Done zählen nur die Pflicht-Abschnitte.

Wie ein ausgefüllter Plan aussieht, zeigt das [Beispiel](team-plan-beispiel.md) (fiktives Team mit Jira, GitLab und Java/TS-Backend). Lest es in Minute 8-12, bevor ihr selbst schreibt.

**Bonus (Teil des Ablaufs, aber kein Muss):** `/verify specs/<slug>.md --pr` hat einen **Draft**-PR/MR geöffnet, mit `Refs #<n>` bzw. `Relates to <KEY>` und dem Verify-Bericht. Nie mergen.

## Zeitplan

| Min. | Was |
|---|---|
| 0-3 | Blatt lesen. Weg B: `gh` auf den eigenen Fork stellen |
| 3-8 | `/verify specs/<slug>.md --pr` starten. Läuft 15-20 Minuten, ihr lasst ihn laufen |
| 8-30 | Währenddessen: Beispiel-Plan lesen (4 Min.), dann in `team-plan.md` die Pflicht-Abschnitte ausfüllen, jede/r für das eigene Team. Ab Minute 22 im Raum die Pläne vergleichen |
| 30-35 | PR/MR ansehen: Draft? Verweis aufs Ticket? Bericht drin? |
| 35-40 | Jede/r postet „Mein erster Schritt am Montag: …“ in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr. Die Debrief-Person postet dazu eine offene Frage des Raums |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

Wird es eng, lasst `--pr` weg. Der Team-Plan bleibt.

## Weg A: euer Repo

1. `verify` bekommt den Schritt „Draft PR/MR“ aus der Vorlage (`## 7. Draft PR/MR (only with --pr)` in `.claude/skills/verify/SKILL.md`). Unter `## Settings` füllt ihr:

   | System | Verweis | PR/MR öffnen und Pipeline abwarten |
   |---|---|---|
   | GitHub | `Refs #42` | Kasten `# GitHub` unten |
   | GitLab | `Relates to #42` | Kasten `# GitLab` unten |
   | Jira | `Relates to KEY-123` | MR im Git-Host (Kasten GitHub bzw. GitLab), Jira-Key in Titel und Branch |

   Die Befehle für `## Settings`, erste Zeile öffnet den PR/MR, zweite wartet auf die Pipeline:

   ```bash
   # GitHub
   gh pr create --draft --base main --title "<title>" --body-file <body>
   gh pr checks --watch --fail-fast
   ```

   ```bash
   # GitLab
   glab mr create --draft -b main -t "<title>" --description-file <body> -y
   glab ci status --wait
   ```

   Das Ticket-Update (Kommentar bzw. Status nach grüner Pipeline) dürft ihr leer lassen.
2. **Pushen nur nach Team-Verfahren.** Ob ein MR mit Spec ins Firmen-Repo geht, entscheidet euer Team. Im Zweifel pusht ihr heute nicht und lasst `/verify` ohne `--pr` laufen. Ob die Spec-Freigabe zusätzlich per MR-Review läuft, legt ihr im Team-Plan fest (Abschnitt 2).
3. Team-Plan in `team-plan.md` ausfüllen. Er ist für euch, nicht für den Raum. Im Raum teilt ihr nur, was ihr zeigen dürft.

## Weg B: Demo-Fork

1. `verify` bekommt den Draft-PR-Schritt. **Empfohlen:** den Abschnitt aus Hilfe 2 an euren eigenen Skill hängen. Oder ihr holt die Musterlösung (überschreibt euren `verify`):

   ```bash
   git checkout origin/stufe/10-verify-pr -- \
     .claude/skills/verify .github/PULL_REQUEST_TEMPLATE.md
   git commit -m "feat(verify): open a draft PR with --pr"
   ```

   **Achtung, Musterlösung:** Ihr `verify` enthält den Browser-Walk aus Stufe 8. Er gibt **Pass** nur, wenn jedes Kriterium im Browser bestanden hat, und dafür braucht er `playwright-cli`. Ohne `playwright-cli` gibt es kein Pass und damit nie einen PR. Prüft vorher `playwright-cli --version`. Fehlt es, eine der zwei Lösungen:

   - Installieren (wie im Ü6-Bonus):

     ```bash
     npm install -g @playwright/cli@latest
     playwright-cli --version
     echo ".playwright-cli" >> .gitignore
     ```

     Startet kein Browser: `playwright-cli install-browser`.
   - Oder den Browser-Schritt bewusst überspringen und das im Bericht vermerken. Dazu die Browser-Bedingung im Verdict ersetzen und committen:

     ```bash
     NEW='- browser walk skipped (no playwright-cli): list it under "Not verified"'
     NEW="$NEW and judge the criteria by code, tests and gates."
     NEW="$NEW" perl -pi -e \
       's/^- every user-facing criterion passed in the browser\.$/$ENV{NEW}/' \
       .claude/skills/verify/SKILL.md
     grep -n "browser walk skipped" .claude/skills/verify/SKILL.md
     git commit -am "chore(verify): skip browser walk, no playwright-cli"
     ```

     Das ist eine bewusste Ausnahme fürs Seminar. Im Bericht und im PR steht dann ehrlich unter „Not verified“, was nicht im Browser geprüft wurde.

2. **`gh` auf euren Fork stellen**, sonst landet der PR im Kurs-Repo. Danach muss euer Name stehen:

   ```bash
   gh repo set-default <euer-github-name>/habit-tracker-demo
   gh repo set-default --view
   ```

3. Neue Session, Port vorher frei (`lsof -i :3110`):

   ```text
   /verify specs/kategorien.md --pr
   ```

   Der Skill pusht nur bei Verdict **Pass** und öffnet dann einen Draft-PR gegen `main` eures Forks mit `Refs #1`. Bei „Issues found“ gibt es keinen PR, dafür einen Bericht. Auch gut. Steht im Bericht als Grund nur „Browser“, fehlt `playwright-cli` (Schritt 1).
4. PR ansehen, **nie mergen**:

   ```bash
   gh pr list
   gh pr view --web
   ```

   `Refs #1` zeigt im Fork ins Leere, weil Forks keine Issues haben. Im echten Repo verknüpft die Zeile PR und Ticket.
5. Danach `gh` zurück auf das Kurs-Repo stellen, damit `/spec 3` in der Hausaufgabe das Issue wieder findet:

   ```bash
   gh repo set-default dinooo13/habit-tracker-demo
   ```

**GitLab oder Jira in der Firma?** Welche Zeilen ihr tauscht, zeigt ein Diff:

```bash
git diff origin/stufe/10-verify-pr origin/kurs/gitlab-jira -- .claude/skills
```

## Leitplanken: was der Agent nicht darf

Für den Abschnitt „Leitplanken“ im Team-Plan. Beispiel aus der Vorlage (`.claude/settings.json`, gilt für alle im Repo, `deny` schlägt `allow`):

```json
{
  "permissions": {
    "deny": [
      "Bash(git push --force*)",
      "Bash(git push -f *)",
      "Bash(git push * --force*)",
      "Bash(git push * -f)",
      "Read(./.env)",
      "Read(./.env.*)",
      "Edit(./.env)",
      "Edit(./.env.*)"
    ]
  }
}
```

Ergänzt eure Deploy-Befehle und Secret-Pfade. Ehrlich dazu: Eine `Bash(…)`-Regel prüft nur den Befehlstext, `git -C . push --force` rutscht durch. Deshalb drei Ebenen:

- **`permissions.deny`** im Repo: Regeln für alle, per MR geändert.
- **Managed Settings** für Firmenregeln (`managed-settings.json`, MDM oder Admin-Konsole): Keine Datei im Repo und kein Entwickler überschreibt sie.
- **Sandbox** (`/sandbox` bzw. `"sandbox": {"enabled": true}`): Bash schreibt nur ins Projekt, Netz nur zu freigegebenen Domains. Datei-Tools regeln weiter die `Read`/`Edit`-Regeln.

## Pro Tool

| Tool | Draft-PR/MR | Leitplanken |
|---|---|---|
| Claude Code | `/verify specs/<slug>.md --pr` | `permissions.deny` in `.claude/settings.json`, Managed Settings, `/sandbox` |
| Codex | `$verify specs/<slug>.md --pr` (Skill gespiegelt). Pushen braucht Netz: In der Sandbox fragt Codex nach oder es scheitert. Dann den Push selbst ausführen. | Sandbox-Modus und Freigaben (`/permissions`), Firmen-Vorgaben siehe Codex-Doku zu Admin-Konfiguration |
| Cursor | `/verify … --pr` im Agent-Chat | Allowlist bzw. Denylist für Terminal-Befehle und Admin-Einstellungen, siehe Cursor-Doku |
| Copilot | `/verify … --pr` im Agent-Modus bzw. in der CLI | Organisations-Policies im GitHub-Admin, in VS Code die Freigaben für Terminal-Befehle, siehe Doku |

Der Draft-PR-Schritt selbst ist tool-neutral: `git push` und eine CLI (`gh`, `glab`).

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß für den Team-Plan</summary>

- Erst das [Beispiel](team-plan-beispiel.md) lesen, dann die Pflicht-Abschnitte 1, 2, 4, 7, 8 und 10 füllen. Der Rest geht zu Hause.
- Fangt klein an: **ein Pilot mit drei echten Tickets**, nicht „ab Montag alle“. Messt vorher die Baseline (wie lange dauert so ein Ticket heute, wie viele Review-Runden), sonst könnt ihr in der Retro nichts vergleichen.
- Die meisten Punkte sind Entscheidungen, die euch kein Skill abnimmt: Wo stehen die Akzeptanzkriterien? Wer gibt die Spec frei? Welche Regel gehört in einen Hook?
- „Wem gehören die Skills“: Wenn sie niemandem gehören, veralten sie in vier Wochen.

</details>

<details>
<summary>Hilfe 2: Abschnitt „Draft PR“ zum Anhängen (Weg B)</summary>

Ans Ende von `.claude/skills/verify/SKILL.md`, dazu im Frontmatter `argument-hint: "[specs/<slug>.md] [--pr]"`:

````markdown
## Draft PR (only with `--pr`)

Only if the user passed `--pr`, the verdict is Pass, and the spec names an issue:

1. Write the PR body to a temporary file: a short summary, the line `Refs #<n>`, and
   the verification report.
2. Push the branch and open the PR as a draft:

   ```bash
   git push -u origin HEAD
   gh pr create --draft --base main --title "<type>: <title>" --body-file <body>
   ```

3. Show the user the PR link.

Use `Refs #<n>`, not `Closes #<n>`: the issue stays open until a human has reviewed
and merged the PR. Never merge, never mark the PR ready, and never open a PR with a
red gate.
````

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

```bash
git diff origin/stufe/09-verify-hook origin/stufe/10-verify-pr
git diff origin/stufe/10-verify-pr origin/kurs/gitlab-jira -- .claude/skills
git diff --stat origin/stufe/10-verify-pr origin/kurs/gitlab-jira
```

Vorlage: README „In 15 Minuten in dein Repo“ und Abschnitt „Leitplanken“ in `rheinwerk-starter-skills`, dazu `templates/` (Issue-, MR- und Jira-Vorlagen).

Team-Plan: das ausgefüllte [Beispiel](team-plan-beispiel.md) in diesem Heft.

</details>

## Rückfall

Weg B: Der Lauf mit `--pr` ist nicht fertig oder sagt „Issues found“? Kein Problem, der PR ist Bonus. Wer den kompletten Endstand haben will (für die Hausaufgabe), legt sich einen Branch aus der letzten Stufe an:

```bash
git add -A && git commit -m "wip: ue7"
git switch --no-track -c seminar/ende origin/stufe/10-verify-pr
```

Weg A: Minimum ist der Team-Plan. Den Draft-MR macht ihr mit dem ersten Pilot-Ticket im Team.

## Bonus für Schnelle

- Im Team-Plan die optionalen Abschnitte 3, 5, 6 und 9 füllen.
- Im Team-Plan die Messgrößen konkret machen: Woher bekommt ihr Durchlaufzeit und Review-Runden (Tracker, Git-Host)?
- Weg B: Issue #2 komplett durch den Flow bis zum Draft-PR.
- Ticket-Vorlage mit Pflichtfeld Akzeptanzkriterien für euren Tracker aus `templates/` der Vorlage vorbereiten.

## Für den Debrief

Leitfrage: **Ein Satz pro Person: Was macht ihr am Montag als Erstes?**

- In den globalen Chat: jede/r „Mein erster Schritt am Montag: …“, die Debrief-Person dazu eine offene Frage des Raums.
- Im Plenum zeigt der Kursleiter die Vorlage und die README „In 15 Minuten in dein Repo“.
- Hausaufgabe: Weg B Issue #3 und #4 mit dem fertigen Flow (siehe `KURS.md` auf `origin/stufe/10-verify-pr`). Weg A: die drei Pilot-Tickets aus eurem Team-Plan.
