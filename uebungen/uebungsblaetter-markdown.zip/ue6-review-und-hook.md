# Ü6 Review-Subagent und harte Regeln im Hook

**Tag 2 · Donnerstag 19.11., nach dem Mittag · Zeitbox 70 Minuten**

## Ziel

Zwei Werkzeuge gegen „der Agent prüft sich selbst gnädig“: Ein Review-Subagent mit frischem Context Window, der nur liest. Und ein Hook, der eine harte Regel prüft, egal was im Prompt steht.

**Done, wenn …**

- [ ] ein Review-Subagent existiert (Claude Code: `.claude/agents/reviewer.md`): frischer Kontext, **nur lesend**, Befunde mit Datei, Zeile und Schwere (blocking / non-blocking),
- [ ] `verify` ihn aufruft, ihm nur Spec-Pfad und Branch gibt (nicht die eigenen Schlüsse), jeden Befund selbst nachprüft und ein offener blockierender Befund das Verdict auf „Issues found“ setzt,
- [ ] ein **selbst gebauter Guard** registriert ist, der **eine harte Regel deterministisch** prüft: Nach Änderung einer riskanten Datei fährt er einen schnellen Test (Blatt „Guard-Vorlage“),
- [ ] ihr den Guard **direkt** aufgerufen habt, einmal grün und einmal rot,
- [ ] ihr jede Zeile eures Guards erklären könnt.

Kann euer Tool keine Hooks, oder sperrt die Firma sie? Dann gilt als Done: dieselbe Regel als Git-`pre-commit`-Hook oder CI-Job (Guard-Vorlage Abschnitt 5, CI-Snippets in Hilfe 2).

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen. Im Raum: Welche Regel bricht bei euch immer? Jede/r wählt eine für den Hook. |
| 5-25 | Reviewer schreiben, in `verify` einbauen |
| 25-50 | Guard bauen (Guard-Vorlage), registrieren, direkt testen (grün und rot) |
| 50-62 | Reviewer allein ausprobieren (Prompt unten) oder `/verify` neu starten |
| 62-66 | Im Raum vergleichen: Was hat der Reviewer gefunden? Welche Regel steckt im Hook? |
| 66-70 | Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Tipp: Zur Halbzeit (nach ca. 35 Minuten) kurz aufstehen, strecken, Wasser holen. Laufende Agenten laufen weiter. Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Weg A: euer Repo

1. Reviewer aus der Vorlage übernehmen und lesen:

   ```bash
   mkdir -p .claude/agents
   cp ../rheinwerk-starter-skills/.claude/agents/reviewer.md \
     .claude/agents/reviewer.md
   ```

   Passt die Liste „Look for“ an euren Stack an (z. B. Migrations, API-Verträge, Berechtigungen).
2. In eurem `verify` den Abschnitt „Fresh review“ aus der Vorlage wieder einfügen (in Ü5 gelöscht), dazu die Berichtsabschnitte „Review findings“ und die Verdict-Bedingung „no blocking finding is open“.
3. **Guard für eure riskante Datei** (die eine, die immer bricht: Migration, OpenAPI-Spec, Übersetzungen, generierter Client …). Das ist der Standardweg. Ihr baut ihn nach dem Blatt **Guard-Vorlage**:
   - Skript aus Abschnitt 2 nach `.claude/hooks/file-guard.sh`, im Block `<ANPASSEN>` eure Muster und euren schnellen Testbefehl eintragen (Beispiele für Gradle, Maven, OpenAPI in Abschnitt 1).
   - Registrieren wie in Abschnitt 3. Habt ihr noch keine `.claude/settings.json`, legt sie mit genau diesem Eintrag an.
4. Direkt testen, grün, rot und neutral (Guard-Vorlage Abschnitt 4, Pfad und Änderung für eure Datei einsetzen).
5. **Agent-Hooks gesperrt?** Derselbe Guard als `pre-commit` (Guard-Vorlage Abschnitt 5) und als CI-Job (Hilfe 2). Testet den `pre-commit` mit einem roten und einem grünen Commit.
6. Optional, wenn Zeit ist: **Stop-Hook** mit euren schnellen Gates aus der Vorlage. Oben in `GATES=( … )` eintragen (Sekunden, kein E2E), den `Stop`-Eintrag aus `settings.json` der Vorlage übernehmen.

   ```bash
   mkdir -p .claude/hooks
   cp ../rheinwerk-starter-skills/.claude/hooks/gates-on-stop.sh .claude/hooks/
   chmod +x .claude/hooks/gates-on-stop.sh
   ```

## Weg B: Demo-Fork

1. **Reviewer** als `.claude/agents/reviewer.md` schreiben (Gerüst in Hilfe 2). Kern: `tools: Read, Grep, Glob, Bash`, Bash nur für lesende Git-Befehle, Eingabe nur Spec-Pfad und Branch, Ausgabe als Tabelle mit `Severity | File:line | Finding`.
2. In `.claude/skills/verify/SKILL.md` nach „Gates“ einfügen:

   ```markdown
   ## Fresh review

   Start the **reviewer** subagent (`.claude/agents/reviewer.md`). It begins with an
   empty context, so the review is not anchored on your own view. Give it only the
   spec path and the branch, not your conclusions. Check each finding yourself in the
   code before you put it in the report, and drop the ones that do not hold.
   ```

   Im Bericht den Abschnitt `## Review findings` mit `### Blocking` und `### Non-blocking` ergänzen, beim Verdict „no blocking review finding is open“.
3. **Guard selbst bauen** (Standardweg). Regel: Ändert der Agent das Datenmodell oder das Zod-Schema, laufen sofort die Schema- und Migrationstests. Das Blatt **Guard-Vorlage** hat das Skript schon mit den Werten für den Demo-Fork:
   - Skript aus Abschnitt 2 nach `.claude/hooks/file-guard.sh`, `chmod +x`, `bash -n` (Syntax).
   - Jede Zeile lesen. Ihr müsst sie im Raum erklären können.
4. In `.claude/settings.json` registrieren (Guard-Vorlage Abschnitt 3).
5. **Direkt testen** (Guard-Vorlage Abschnitt 4): grün (ca. 3 s, `systemMessage` „Tests grün“), rot (`"decision": "block"` mit den roten Tests), neutral (`README.md`, keine Ausgabe). Danach einmal im echten Lauf.

   Erst danach, als Vergleich: die Musterlösung `schema-guard.sh` aus Stufe 9. Was macht sie mehr als euer Guard?

   ```bash
   git show origin/stufe/09-verify-hook:.claude/hooks/schema-guard.sh
   ```

   **Optional, wenn Zeit ist: Stop-Hook `gates-on-stop`** aus Stufe 9 (Lint und Unit-Tests am Turn-Ende, rot blockt einmal). Den baut ihr nicht selbst, ihr übernehmt und lest ihn:

   ```bash
   git checkout origin/stufe/09-verify-hook -- .claude/hooks/gates-on-stop.sh
   ```

   Registrieren: in `.claude/settings.json` neben `PostToolUse` ergänzen:

   ```json
   "Stop": [
     {
       "hooks": [
         {
           "type": "command",
           "command": "\"${CLAUDE_PROJECT_DIR}\"/.claude/hooks/gates-on-stop.sh",
           "timeout": 180
         }
       ]
     }
   ]
   ```

   Stop-Hook direkt testen, grün (ca. 15 s, keine Ausgabe heißt grün):

   ```bash
   IN="{\"stop_hook_active\":false,\"cwd\":\"$PWD\"}"
   echo "$IN" | .claude/hooks/gates-on-stop.sh; echo "exit $?"
   ```

   Stop-Hook, rot (Lint-Fehler einbauen, Hook erneut aufrufen, dann aufräumen). Erwartet: `"decision": "block"`.

   ```bash
   echo 'const unused = 1' >> app/utils/domain/date.ts
   IN="{\"stop_hook_active\":false,\"cwd\":\"$PWD\"}"
   echo "$IN" | .claude/hooks/gates-on-stop.sh
   git checkout -- app
   ```

   Der Stop-Hook läuft nur, wenn sich seit seinem letzten Lauf etwas geändert hat. Zum erneuten Testen ohne Änderung:

   ```bash
   rm -f "$(git rev-parse --git-path claude-gates-on-stop)"
   ```

6. Committen:

   ```bash
   git add .claude && git commit -m "feat(verify): add reviewer subagent and hook"
   ```

## Reviewer allein ausprobieren

Neue Session:

```text
Starte den Subagenten reviewer.
Gib ihm nur: Spec specs/kategorien.md, Branch <euer Branch>, Basis main.
Zeig mir seine Befunde unverändert und prüfe danach jeden Befund selbst im Code.
```

## Pro Tool

| Tool | Reviewer | Hook | Wenn es nicht geht |
|---|---|---|---|
| Claude Code | `.claude/agents/reviewer.md`, `tools: Read, Grep, Glob, Bash`. `/agents` zeigt ihn. | `.claude/settings.json`, Events `PostToolUse` (Matcher `Edit\|Write`) und `Stop`. `/hooks` zeigt die registrierten Hooks. | - |
| Codex | `.codex/agents/reviewer.toml` aus der Vorlage (`name`, `description`, `developer_instructions`). Codex erzwingt „nur lesen“ nicht pro Agent, der Subagent erbt die Sandbox der Session. Der Skill muss ihn ausdrücklich starten („Spawn the reviewer subagent …“). | `.codex/hooks.json`, Aufbau wie bei Claude Code (Event → Matcher → Command). `Stop` mit `{"decision":"block","reason":…}` lässt Codex weiterarbeiten. Projekt-Hooks laden nur, wenn ihr dem Ordner vertraut **und** den Hook einmal über `/hooks` freigebt. Neue oder geänderte Hooks überspringt Codex bis zur Freigabe. Verlasst euch nicht auf `${CLAUDE_PROJECT_DIR}`, gebt den Pfad relativ zum Repo-Root an. | Datei-Änderungen laufen über `apply_patch`, ein Dateipfad im Hook-Input ist nicht dokumentiert. Für einen Datei-Guard: Git-`pre-commit` oder CI. |
| Cursor | `.cursor/agents/reviewer.md` oder er liest `.claude/agents/`. Frontmatter `readonly: true` macht ihn schreibgeschützt. | Liest die Claude-Hooks aus `.claude/settings.json` mit (Einstellung „Include Third-Party Plugins, Skills, and Other Configs“, Standard an). Nativ: `.cursor/hooks.json` mit `"version": 1`, Events `stop` und `afterFileEdit`. | Nativer `afterFileEdit` liefert `file_path` direkt, nicht unter `tool_input`. Der Guard aus der Vorlage liest beides. |
| Copilot | `.github/agents/reviewer.agent.md`, Tools auf Lesen beschränken, z. B. `tools: ['read', 'search']`. „Do not edit“ im Text allein ist keine Grenze. | Copilot CLI und VS Code (Preview) lesen `.github/hooks/*.json` und `.claude/settings.json`. In der CLI blockt `Stop` bzw. `agentStop` mit `{"decision":"block",…}`. VS Code: Blocken am Turn-Ende siehe Doku. | Die Tool-Argumente heißen im camelCase-Format (`postToolUse`) `toolArgs`, im PascalCase-Format (`PostToolUse`) `tool_input`. Feldnamen der Edit-Tools in der Doku prüfen. Sonst für den Datei-Guard: Git-`pre-commit` oder CI. |

Für alle gilt: Ein Hook ist ein Shell-Skript. Testet es immer zuerst direkt mit `echo '{…}' | skript.sh`, bevor ihr es dem Agenten unterschiebt.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Kontext-Datei und Skill sind **beratend**, der Agent kann sie übersehen. Ein Hook ist **Konfiguration**: Der Harness führt ihn aus. Faustregel: Was ihr schon zweimal in `AGENTS.md` „bitte denk daran“ geschrieben habt, gehört in einen Hook.
- Der Reviewer bekommt bewusst **nicht** die Begründung des Autors. Er urteilt über den Code, nicht über die Erklärung.
- Stop-Hooks brauchen einen Schleifenschutz: Ist `stop_hook_active` true, arbeitet der Agent schon wegen des Hooks weiter. Dann nicht noch einmal blocken.

</details>

<details>
<summary>Hilfe 2: Gerüste zum Kopieren</summary>

`.claude/agents/reviewer.md`:

````markdown
---
name: reviewer
description: Read-only reviewer of a branch against its spec. Never edits files.
tools: Read, Grep, Glob, Bash
---

You review one feature branch. You start without the author's context on purpose.
You only read. Use Bash only for read-only git commands (`git diff`, `git log`,
`git show`). Never edit files, never change the index or branches, run no tests.

Input: the spec path and the branch. Nothing else.

1. Read the spec, `AGENTS.md` and the ADRs the diff touches.
2. Read `git diff main...HEAD`, open changed files where the diff is not enough.
3. Look for: wrong behavior against the spec, missed edge cases (empty states,
   active filters, reload, old data, mobile), violated ADRs or hard rules,
   criteria no test would catch, scope creep.
4. Check each finding in the code. Drop what you cannot point to.

Output, at most about 40 lines:
| # | Severity | File:line | Finding | Why it matters |
Severity: blocking or non-blocking. Then "Checked and fine", one line per area.
````

Guard: das Skript steht vollständig auf dem Blatt **Guard-Vorlage** (Abschnitt 2), ebenso der `pre-commit`, der denselben Guard nutzt (Abschnitt 5).

Den Guard vom Agenten schreiben lassen ist erlaubt, wenn ihr jede Zeile erklären könnt:

```text
Schreib .claude/hooks/file-guard.sh als PostToolUse-Hook für Claude Code:
JSON von stdin lesen, tool_input.file_path holen,
nur bei <eure Datei> weitermachen, im Repo-Root <euer Testbefehl> fahren.
Grün: {"systemMessage": …}.
Rot: {"decision": "block", "reason": …} mit den letzten 30 Zeilen.
Immer Exit 0. Höchstens 40 Zeilen. Erkläre danach jede Zeile in einem Satz.
```

**CI-Job: dieselben Gates vor dem Merge.** Die Snippets fahren die Gates des Demo-Repos (wie `.github/workflows/ci.yml` auf `origin/stufe/10-verify-pr`, dort mit Build und Caching). Weg A: `image` bzw. `setup-node` und die Befehle tauschen, z. B. `eclipse-temurin:21` und `./gradlew spotlessCheck test`.

**YAML braucht die Einrückung.** Beim Kopieren aus dem PDF geht sie **immer** verloren. Kopiert YAML nur aus dem Markdown-Zip (`uebungsblaetter-markdown.zip`, Datei `ue6-review-und-hook.md`). Doch aus dem PDF kopiert? Dann den Agenten reparieren lassen (`Rücke diese Datei als gültiges YAML ein, ändere sonst nichts.`) und prüfen: GitLab `glab ci lint`, GitHub `actionlint`.

GitLab, `.gitlab-ci.yml`. Der Job `schema-guard` ist die Guard-Regel: Er läuft nur, wenn eine riskante Datei im MR geändert ist.

```yaml
# .gitlab-ci.yml: dieselben Gates wie lokal, für jeden MR und den Default-Branch
workflow:
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    - if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH

default:
  image: node:22
  cache:
    key: { files: [package-lock.json] }
    paths: [.npm/]
  before_script:
    - npm ci --cache .npm --prefer-offline

gates:
  stage: test
  script:
    - npm run lint
    - npm run typecheck
    - npm test

e2e:
  stage: test
  variables: { PORT: "3110", E2E_PORT: "3110" }
  script:
    - npx playwright install --with-deps chromium
    - npm run test:e2e

# Die Guard-Regel als eigener Job: nur, wenn eine riskante Datei geändert ist.
schema-guard:
  stage: test
  rules:
    - changes:
        - app/types/app-data.ts
        - app/utils/persistence/storage-schema.ts
  script:
    - npx vitest run --project unit storage-schema schema-migrations pause-mode
```

Pflicht vor dem Merge: in GitLab unter Settings → Merge requests → Merge checks „Pipelines must succeed“ aktivieren.

GitHub Actions, `.github/workflows/gates.yml`. Die Schema-Tests stecken hier schon in `npm test`:

```yaml
# .github/workflows/gates.yml: dieselben Gates wie lokal, für jeden PR
name: Gates
on:
  pull_request:
  push:
    branches: [main]
permissions:
  contents: read
jobs:
  gates:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-node@v6
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test
  e2e:
    runs-on: ubuntu-latest
    env: { PORT: 3110, E2E_PORT: 3110 }
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-node@v6
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npx playwright install --with-deps chromium
      - run: npm run test:e2e
```

Pflicht vor dem Merge: unter Settings → Rules → Rulesets (oder Branch protection) für `main` „Require status checks to pass“ mit den Checks `gates` und `e2e`.

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

```bash
F=.claude/skills/verify/SKILL.md
git show origin/stufe/07-verify-review:.claude/agents/reviewer.md
git diff origin/stufe/06-verify-spec-abgleich origin/stufe/07-verify-review -- $F
git diff --stat origin/stufe/08-verify-browser origin/stufe/09-verify-hook
git show origin/stufe/09-verify-hook:.claude/settings.json
git show origin/stufe/09-verify-hook:.claude/hooks/schema-guard.sh
```

`schema-guard.sh` ist die ausgebaute Fassung eures Guards: dieselbe Regel, dazu ein Hinweis auf den Skill `schema-change` und eine Zusammenfassung der Testzahlen.

Weg A: `.claude/agents/reviewer.md`, `.claude/hooks/gates-on-stop.sh` und `.claude/settings.json` in der Vorlage, für Codex `.codex/agents/reviewer.toml`.

</details>

## Rückfall

Weg B: Reviewer, Verify mit Review (und Browser-Check) und beide Hooks aus Stufe 9 holen, dann weiter mit Ü7:

```bash
git checkout origin/stufe/09-verify-hook -- .claude AGENTS.md
git commit -m "feat(verify): reviewer, hooks (Musterlösung Stufe 9)"
```

Das überschreibt eure Skills unter `.claude/` mit der Musterlösung. Wer seine behalten will, holt nur die fehlenden Teile, z. B.:

```bash
git checkout origin/stufe/09-verify-hook -- \
  .claude/agents .claude/hooks .claude/settings.json
```

Codex danach spiegeln.

Weg B, nur der Guard fehlt:

```bash
git checkout origin/stufe/09-verify-hook -- \
  .claude/hooks/schema-guard.sh .claude/skills/schema-change
```

Danach den `PostToolUse`-Eintrag aus der Guard-Vorlage mit `schema-guard.sh` statt `file-guard.sh` registrieren.

Weg A: Minimum für Ü7 ist der Reviewer aus der Vorlage und ein Guard aus der Guard-Vorlage mit eurem Testbefehl (oder derselbe Guard als `pre-commit`).

## Bonus für Schnelle

- **Browser-Check** wie Stufe 8: Schritt „Browser walk“ in `verify`, der jedes Kriterium im echten Browser klickt, mit Reload und mobiler Breite.

  ```bash
  npm install -g @playwright/cli@latest
  playwright-cli --version
  echo ".playwright-cli" >> .gitignore
  F=.claude/skills/verify/SKILL.md
  git diff origin/stufe/07-verify-review origin/stufe/08-verify-browser -- $F
  ```

  Startet kein Browser: `playwright-cli install-browser`.
- Guard im echten Lauf: neue Session, `Setze APP_DATA_SCHEMA_VERSION in app/types/app-data.ts auf 3`. Was passiert? Danach `git checkout -- app`.
- CI-Job aus Hilfe 2 in euren Fork legen, einen Draft-PR mit einer kaputten Migration öffnen und zusehen, wie `gates` rot wird.
- Reviewer auf `kurs/verify-rot` loslassen (Branch aus dem Ü5-Bonus). Findet er den Leerzustand-Fehler als „blocking“?

### Bonus BMad: zweites Review mit `bmad-code-review`

Nur, wenn Reviewer und Guard stehen. Ihr lasst das Review von [BMad Method](https://github.com/bmad-code-org/BMAD-METHOD/blob/V6.12/docs/build/review-a-change.md) 6.12.4 mit **einer eigenen Review-Ebene** neben eurem `reviewer` auf denselben Diff los und vergleicht. `bmad-code-review` bringt vier Ebenen mit: Blind Hunter (sieht nur den Diff), Edge Case Hunter, Verification Gap und Acceptance Auditor (Diff gegen Spec, nur mit Spec-Pfad). Jeder Befund bekommt eine Triage: `decision_needed`, `patch`, `defer` oder `dismiss`.

Was gleich bleibt: **Euer Guard.** BMad hat keine Hooks. Eine Review-Ebene ist eine Bitte an ein Modell, der Guard läuft immer.

Im Test (Demo-Repo, Claude Code, Sonnet): erster Lauf 3 Patches, 1 Defer, 13 verworfen; im zweiten Lauf lief die eigene Ebene mit. Voraussetzungen wie im Ü3-Bonus (Vorab-Info).

1. **Wegwerf-Worktree.** Weg B, und Weg A zum Ausprobieren: aus `origin/bmad/05-verify-hooks`. Dort sind BMad, das fertige Feature zu Issue #1 und die BMad-Spec mit `baseline_commit`. Im Fork-Ordner (fehlen die `bmad/*`-Branches: Block im Ü3-Bonus):

   ```bash
   git fetch origin
   git worktree add -b wegwerf/bmad-review ../habit-review \
     origin/bmad/05-verify-hooks
   cd ../habit-review
   printf '%s\n' '[core]' 'user_name = "Vorname Nachname"' \
     'communication_language = "German"' > _bmad/custom/config.user.toml
   ```

   Im eigenen Repo (Weg A) geht es auch: Installation wie im Ü3-Bonus, Variante 2, aber den Worktree aus eurem Übungs-Branch statt aus `origin/main`. Merkt euch dort vor der Installation die Commits eures Features, ihr braucht sie in Schritt 3:

   ```bash
   echo "$(git merge-base origin/main HEAD)..$(git rev-parse HEAD)"
   ```

2. **Eigene Ebene** in `_bmad/custom/bmad-code-review.toml`: eine Team-Regel, die die vier Ebenen nicht prüfen. Weg B, die Datei aus dem Testlauf (dort geladen und gelaufen):

   ```bash
   mkdir -p _bmad/custom
   cat > _bmad/custom/bmad-code-review.toml <<'TOML'
   # Team review layer for bmad-code-review (committed).
   [[workflow.review_layers]]
   id = "schema-test-guard"
   name = "Schema Test Guard"
   instruction = """
   Launch a context-free subagent with this prompt:

   You check one team rule. Read the unified diff at `{diff_file}`.
   Rule: every change to `app/types/app-data.ts` or `app/utils/persistence/`
   needs a matching new or changed test in `tests/` in the same diff, and a
   new ADR in `docs/adr/`.
   For each changed schema file, name the test file that covers it, or report
   "missing test for <file>". Report "missing ADR" if no ADR file is added.
   Output a Markdown list of findings only; say "no findings" if the rule holds.

   Do not invoke any skill, and do not spawn subagents of your own. Return your
   findings as text in your final message.
   """
   TOML
   ```

   Weg A: `id`, `name` und die Zeilen unter `Rule:` tauschen, z. B. „jede neue API-Route hat einen Eintrag in `api/openapi.yaml`“. Eine Regel, am Diff prüfbar. Neue `id` hängt eine Ebene an, eine bestehende `id` ersetzt die Standard-Ebene. Prüfen ohne Agent, dann committen:

   ```bash
   uv run --no-cache _bmad/scripts/resolve_customization.py \
     --skill "$PWD/.claude/skills/bmad-code-review" -p "$PWD" \
     --key workflow.review_layers | grep '"id"'
   git add _bmad/custom/bmad-code-review.toml
   git commit -q -m "chore(bmad): add review layer"
   ```

   Erwartet: die vier Standard-IDs und eure als fünfte. Codex, Cursor, Copilot: `.agents/skills/bmad-code-review` im Befehl.
3. **Frische Session, Review mit Spec-Pfad.** Ohne Spec-Pfad vergleicht der Skill den Branch gegen `main`, und dann liegt die ganze BMad-Installation im Diff. Weg B:

   ```text
   /bmad-code-review _bmad-output/implementation-artifacts/spec-<slug>.md
   ```

   Den Slug zeigt `ls _bmad-output/implementation-artifacts/`, auf `bmad/05-verify-hooks` ist es `gh-1-habit-categories-filter`.

   Im eigenen Repo gibt es keine BMad-Spec. Dann mit den Commits aus Schritt 1, ohne Spec (so getestet, der Acceptance Auditor läuft dann nicht):

   ```text
   /bmad-code-review commit range <von>..<bis>, no spec
   ```

4. **Das Review hält bis zu dreimal an.**
   - **Halt 1, Kontext:** Ziel, Modus und Umfang. Weg B: ca. 40 Dateien ab `baseline_commit`. Stimmt das, „weiter“. Nennt es Hunderte Dateien: abbrechen, Spec-Pfad oder Range prüfen. Eure Ebene muss unter den aktiven Ebenen stehen.
   - **Halt 2, Entscheidungen:** nur, wenn es Befunde mit `decision_needed` gibt. Mit der Nummer der Option antworten.
   - **Halt 3, Patches:** `1` alle anwenden, `2` als Action Items stehen lassen, `3` einzeln durchgehen. Für den Vergleich: **`2`**.

   Der Skill schreibt die Befunde als Abschnitt in die Spec, Defers nach `deferred-work.md`. **Patches committet er nicht selbst.** Wer im Wegwerf-Worktree `1` wählt, prüft jeden Patch selbst und committet ihn selbst. Empfiehlt er am Ende `dev-story`: ignorieren, das ist in 6.12 veraltet.
5. **Euren `reviewer` auf denselben Diff.** Kopiert ihn aus eurem Übungs-Branch in den Worktree und startet eine neue Session (Weg B, Fork-Ordner heißt hier `../habit-tracker-demo`):

   ```bash
   mkdir -p .claude/agents
   cp ../habit-tracker-demo/.claude/agents/reviewer.md .claude/agents/
   ```

   ```text
   Starte den Subagenten reviewer.
   Gib ihm nur: Spec _bmad-output/implementation-artifacts/spec-<slug>.md,
   Branch HEAD, Basis 365e464.
   Zeig mir seine Befunde unverändert.
   ```

   `365e464` ist der `baseline_commit` der Spec, also derselbe Diff wie bei BMad. Weg A: eure Range aus Schritt 1.
6. **Vergleichen.** Was fanden beide? Was nur BMad, was nur euer Reviewer? Welcher Befund war falsch? Was hat eure eigene Ebene gemeldet, und gehört die Regel besser in den Guard?
7. **Aufräumen**, im Haupt-Checkout:

   ```bash
   git worktree remove --force ../habit-review
   git branch -D wegwerf/bmad-review
   ```

<details>
<summary>Fallstricke BMad-Review (aus den Testläufen)</summary>

- **Spec-Pfad oder Range angeben.** Ohne beides fragt das Review, ob es gegen `main` prüfen soll. Im Wegwerf-Branch läge dann die BMad-Installation im Diff.
- **Review findet immer etwas.** Der Blind Hunter muss je nach Diff-Größe eine Mindestzahl an Befunden liefern. Im Test fand ein Review der Review-Patches wieder zwei neue. Höchstens zwei Läufe, der Rest wird ein Ticket.
- **Nichts wird committet.** Patches liegen danach ungestaged im Worktree. Im Test hat der Agent beim Patchen ein akzeptiertes ADR geändert, obwohl `AGENTS.md` das verbietet: jeden Patch selbst lesen.
- **Sprache:** Ohne `_bmad/custom/config.user.toml` antwortet das Review auf Englisch.
- **Ohne Subagenten** schreibt das Review laut Quelltext die Prompts der Ebenen in Dateien unter `_bmad-output/implementation-artifacts/` und hält an, sonst laufen die Ebenen nacheinander in der Hauptsession, laut BMad deutlich schwächer.
- **Codex, Cursor, Copilot:** Skills unter `.agents/skills/` (auf `bmad/05-verify-hooks` nur unter `.claude/skills/`, für Codex spiegeln wie im Ü3-Bonus). Copilot in VS Code liest laut Doku `.github/skills/`: `/` tippen, sonst spiegeln. **Agentenläufe in Codex, Cursor und Copilot sind nicht getestet.**
- **`npx skills add …` nicht ausführen,** auch wenn der Installer es empfiehlt (holt v7).
- **Override wirkt erst in einer neuen Session.** Eine laufende Session nutzt den Stand vom Start.

</details>

## Für den Debrief

Leitfrage: **Welche Regel steht jetzt im Hook statt im Prompt? Was hat der Reviewer gefunden?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): eure Hook-Regel in einem Satz, der beste Reviewer-Befund, eine Frage.
- Im Plenum zeigen zwei Räume ihren Guard grün und rot und erklären ihn. Der Kursleiter zeigt danach `schema-guard.sh` aus Stufe 9.
