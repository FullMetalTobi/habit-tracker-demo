# Ü4 Code-Skill und erster `/code`-Lauf

**Tag 2 · Donnerstag 19.11., am Vormittag · Zeitbox 65 Minuten**

## Ziel

Ihr schreibt einen `code`-Skill, der eine freigegebene Spec Task für Task umsetzt: Test zuerst, ein Commit pro Task, Gates am Ende. Dann lasst ihr ihn in einer neuen Session auf eurer Spec laufen.

**Done, wenn …**

- [ ] `.claude/skills/code/SKILL.md` existiert und als **harte Regel** sagt: kein Produktionscode, bevor der Test des Tasks rot war; ein Conventional Commit pro Task; Gates am Ende grün; Start nur bei `Status: approved`,
- [ ] `/code specs/<slug>.md` in einer **neuen Session** gelaufen ist,
- [ ] alle Tasks der Spec committet sind (`- [x]` in der Spec, ein Commit pro Task),
- [ ] die Gates grün sind (Weg B: `npm run lint && npm run typecheck && npm test`).

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen. Stand prüfen: Ist eure Spec freigegeben? (`grep -n "Status:" specs/*.md`) |
| 5-22 | `code`-Skill schreiben |
| 22-27 | Rechte einrichten, neue Session, `/code specs/<slug>.md` starten |
| 27-50 | Lauf beobachten (Weg B ca. 10-15 Min.). Währenddessen im Raum die Commits der Musterlösung ansehen und Rückfragen des Agenten sofort beantworten |
| 50-58 | Ergebnis prüfen: Commits, Red-Zeilen, Gates |
| 58-65 | Im Raum vergleichen. Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

**Spec noch nicht freigegeben?** Erst den Rückfall-Block von [Blatt Ü3](ue3-spec-voll-und-freigabe.md#rückfall) nehmen, dann hier weiter.

## Weg A: euer Repo

1. Skill aus der Vorlage übernehmen und anpassen, oder selbst schreiben (Gerüst in Hilfe 2):

   ```bash
   mkdir -p .claude/skills/code
   cp ../rheinwerk-starter-skills/.claude/skills/code/SKILL.md \
     .claude/skills/code/SKILL.md
   grep -n ANPASSEN .claude/skills/code/SKILL.md
   ```

   Zu füllen: Basis-Branch und Branch-Schema, schnelle Gates, E2E-Gate, Test-Ordner. **Keine E2E-Tests im Repo?** Schreibt bei E2E `none` hinein und löscht den E2E-Schritt. Dann trägt der Test-Plan der Spec die Last.
2. Committen: `git add .claude/skills/code && git commit -m "feat(skills): add the code skill"`.
3. **Rechte:** Im Firmen-Repo keinen Vollzugriff. Erlaubt gezielt eure Gate-Befehle sowie `git add` und `git commit` (Claude Code: Allow-Liste in `.claude/settings.local.json`, siehe Weg B, eure Befehle einsetzen). Alles andere bestätigt ihr einzeln.

   **Claude Code ab 2.1.283 startet im Auto-Modus** (Statuszeile `auto mode on`). Dann bestätigt ihr nicht einzeln, ein Klassifizierer-Modell prüft die Aktionen. Enge Allow-Regeln wie `Bash(npm test)` gelten weiter, breite wie `Bash(*)` setzt der Auto-Modus aus. Verlangt eure Firma Einzelfreigaben, stellt im Firmen-Repo auf den Standard-Modus:

   ```bash
   claude --permission-mode default
   ```

   In der Session wechselt Shift+Tab von `auto` auf `default`. Dauerhaft für alle eure Sessions: `"permissions": { "defaultMode": "default" }` in `~/.claude/settings.json`.
4. Neue Session, `/code specs/<slug>.md`. Rückfragen sofort beantworten.
5. Läuft der Lauf in eurem Repo deutlich länger als die Zeitbox (großer Build, langsame Tests)? Lasst ihn laufen und prüft parallel die Musterlösung in Weg B (Hilfe 3).

## Weg B: Demo-Fork

1. Auf `seminar/kategorien` den `code`-Skill schreiben (Gerüst in Hilfe 2) und committen:

   ```bash
   git add .claude/skills/code && git commit -m "feat(skills): add the code skill"
   ```

2. Rechte für den Lauf, eine der beiden Varianten:
   - **Allow-Liste** (so würdet ihr es im Firmen-Repo machen). Datei `.claude/settings.local.json` anlegen. Sie ist persönlich, über `.git/info/exclude` (Ü2) wird sie nie committet:

     ```json
     {
       "env": { "PORT": "3110", "E2E_PORT": "3110" },
       "permissions": {
         "allow": [
           "Bash(gh issue view *)",
           "Bash(npm test)", "Bash(npm test *)",
           "Bash(npm run test:unit *)", "Bash(npm run test:nuxt *)",
           "Bash(npm run lint)", "Bash(npm run lint *)", "Bash(npm run lint:fix)",
           "Bash(npm run typecheck)",
           "Bash(npx vitest *)", "Bash(npx eslint *)",
           "Bash(PORT=3110 E2E_PORT=3110 npm run test:e2e)",
           "Bash(PORT=3110 E2E_PORT=3110 npm run test:e2e *)",
           "Bash(PORT=3110 E2E_PORT=3110 npx playwright test *)",
           "Bash(git add *)", "Bash(git commit *)",
           "Bash(git checkout -b *)", "Bash(git switch -c *)"
         ]
       }
     }
     ```

   - **Auto-Modus bzw. Vollzugriff:** im Demo-Fork vertretbar (keine Secrets, eigener Fork). Im Firmen-Repo nicht. Befehle pro Tool unter „Pro Tool“.
3. Neue Session:

   ```text
   /code specs/kategorien.md
   ```

4. Während der Lauf geht (ca. 10-15 Min.), die Musterlösung ansehen, jede/r für sich oder gemeinsam, wenn jemand den Bildschirm teilen mag:

   ```bash
   git log --oneline --no-merges origin/stufe/02-spec-voll..origin/stufe/03-code
   ```

   10 Commits: der Skill, die Freigabe, 7 Tasks = 7 Commits und der Nachtrag `5d1aaeb` zur TDD-Regel. Einen Task-Commit öffnen: `git show --stat 3112d3f`.
5. Nach dem Lauf prüfen:

   ```bash
   git log --oneline --no-merges origin/main..HEAD
   git log --no-merges --format="%h %s%n%b" origin/main..HEAD \
     | grep -E "^[0-9a-f]{7}|Red:"
   grep -n "\- \[" specs/kategorien.md
   npm run lint && npm run typecheck && npm test
   ```

   Abweichungen zur Musterlösung (andere Dateinamen, andere Tests) sind normal. Genau deshalb prüft `/verify` in Ü5 gegen die Spec und nicht gegen einen Referenz-Diff.

## Pro Tool

| Tool | Neue Session | Rechte für den Lauf | Hinweis |
|---|---|---|---|
| Claude Code | `/clear` oder neu starten | Allow-Liste (oben) oder Auto-Modus (ab 2.1.283 Start-Modus; sonst `claude --permission-mode auto` bzw. Shift+Tab bis „auto mode on“). Einzelfreigaben: `claude --permission-mode default`. Im Demo-Fork auch ohne Rechte-Abfragen (Kasten unter der Tabelle) | `disable-model-invocation: true` im Frontmatter: `/code` startet nur, wenn ihr es tippt |
| Codex | `/new` | `/permissions`. Startet der Browser für E2E in der Sandbox nicht, im Demo-Fork Full Access | Skill spiegeln (Kasten unter der Tabelle) und mit `$code specs/kategorien.md` aufrufen |
| Cursor | neuer Chat | Auto-Run für Terminal-Befehle in den Cursor-Einstellungen, im Firmen-Repo nur mit Allowlist | Lange Läufe: Chat offen lassen, Rückfragen kommen dort |
| Copilot | neuer Chat, CLI `/clear` | VS Code: Terminal-Befehle einzeln bestätigen oder Auto-Approve laut Doku. CLI: `/allow-all` nur im Demo-Fork | Business/Enterprise: Admin muss Terminal im Agent-Modus erlauben. VS Code: Skill nach `.github/skills/` spiegeln, falls `/code` fehlt |

Claude Code im Demo-Fork ohne Rechte-Abfragen (nie im Firmen-Repo):

```bash
claude --dangerously-skip-permissions
```

Codex, Skill spiegeln (im Repo-Ordner):

```bash
mkdir -p .agents && cp -R .claude/skills .agents/
```

Für alle Tools gilt: Die Spec ist die Wahrheit. Ein Lauf in einer neuen Session sieht nur Spec, `AGENTS.md` und Repo, nicht euren Chat von gestern.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- „Schreib Tests“ reicht nicht. Agenten schreiben Test und Code gern zusammen. Die Regel muss hart sein: **Test ausführen, Fehlschlag zeigen, erst dann Code.** Und prüfbar: der Name des roten Tests steht im Commit (`Red: <test>`).
- Ein Commit pro Task heißt: Der Skill hakt den Task in der Spec ab (`- [x]`). So kann eine neue Session nach einem Abbruch weitermachen.
- „Startet nur bei approved“: Der Skill liest die Kopfzeile. Steht `draft`, fragt er, statt loszulegen.

</details>

<details>
<summary>Hilfe 2: Gerüst zum Kopieren</summary>

````markdown
---
name: code
description: Implement an approved spec from specs/ task by task, test first.
argument-hint: "[specs/<slug>.md]"
disable-model-invocation: true
---

# Code

Implement the approved spec: **$ARGUMENTS**

## 1. Load the spec
- Read the whole spec. It is the scope: no more, no less.
- If the header says `Status: draft`, ask before you write code.
- Read the files under Research and the ADRs it names.

## 2. Branch
- Never work on `main`. Start from a clean tree and run the unit tests once.

## 3. Each task, in order
1. **Red.** Write the test for the task and run it. It must fail for the right
   reason. **Hard rule: no production code before you have seen this test fail.**
   Show the command and the failing assertion. No testable behavior (ADR, docs)?
   Say `No test: <reason>`.
2. **Green.** Smallest change that makes it pass. Follow the patterns around it.
3. **Refactor** while green.
4. **Commit** one Conventional Commit per task, body line `Red: <test name>`.
   Tick the task in the spec (`- [x]`). Never commit a red state.

If a task is wrong or impossible, stop and tell the user. Do not change scope.

## 4. Gates
<eure Gate-Befehle>. Fix failures at the cause. Never weaken, skip or delete a test.

## 5. Report
Branch, commits, decisions on the way, gate results, open risks.
Suggest `/verify specs/<slug>.md`. Do not push, open a PR or merge.
````

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

```bash
git show origin/stufe/03-code:.claude/skills/code/SKILL.md
git log --oneline --no-merges origin/stufe/02-spec-voll..origin/stufe/03-code
git diff --stat origin/stufe/02-spec-voll origin/stufe/03-code
```

Ehrlich dazu: Die Feature-Commits der Musterlösung entstanden vor der TDD-Regel (Commit `5d1aaeb` „make TDD explicit“). Sie haben deshalb noch keine `Red:`-Zeile. Euer Lauf sollte sie haben.

Weg A: `.claude/skills/code/SKILL.md` in der Vorlage.

</details>

## Rückfall

Weg B: `/code` hängt, ist rot oder nicht fertig? Rest sichern und auf dem Stand der Musterlösung weitermachen. Dort ist das Feature fertig und die Spec freigegeben:

```bash
git add -A && git commit -m "wip: ue4 nicht fertig"
git switch --no-track -c seminar/ab-ue5 origin/stufe/03-code
```

Eure Skills und `AGENTS.md` nehmt ihr mit:

```bash
git checkout seminar/kategorien -- AGENTS.md .claude/skills
git commit -m "chore: eigene Skills übernehmen" || true
```

`|| true` fängt nur „nothing to commit“ ab: Sind eure Skills schon gleich, gibt es nichts zu committen, und das ist in Ordnung.

Ab jetzt arbeitet ihr auf `seminar/ab-ue5` statt `seminar/kategorien`. Codex: `.agents/skills` danach neu spiegeln, Copilot in VS Code ggf. `.github/skills`.

Weg A: Minimum für Ü5 ist ein Branch mit einer Änderung, die zu eurer Spec passt, auch wenn nur ein Teil der Tasks fertig ist. `/verify` darf dann „Issues found“ sagen, genau das übt ihr in Ü5.

## Bonus für Schnelle

- Den Lauf abbrechen (Ctrl-C bzw. Stopp) und in einer neuen Session `/code specs/<slug>.md` erneut starten. Macht er beim nächsten offenen Task weiter?
- Weg B: Issue #2 durch `/spec` und `/code` (Branch aus Ü3-Bonus).
- Prüft einen Commit von Hand: Hätte der Test ohne den Produktionscode wirklich versagt? `git show <sha> -- tests e2e`.

## Für den Debrief

Leitfrage: **Hat der Agent wirklich zuerst den Test geschrieben? Wie viele Commits?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): Anzahl Commits, Anzahl mit `Red:`-Zeile, Gates grün ja/nein, und eine Frage.
- Im Plenum zeigen zwei Räume `git log --oneline`. Der Kursleiter zeigt `git log` von Stufe 3.
