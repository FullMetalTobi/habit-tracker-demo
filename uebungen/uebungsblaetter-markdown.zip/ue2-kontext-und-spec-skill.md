# Ü2 Kontext-Datei und erster Spec-Skill

**Tag 1 · Mittwoch 18.11., nach dem Mittag · Zeitbox 70 Minuten**

## Ziel

Ihr schreibt eine kurze `AGENTS.md` aus eurer Liste von Ü1 und einen minimalen `spec`-Skill. Der Skill läuft einmal auf eurem Ticket und schreibt eine Spec-Datei.

**Done, wenn …**

- [ ] `AGENTS.md` im Repo-Root liegt, **höchstens ca. 60 Zeilen**, mit: Gates (kopierbare Befehle), Architektur-Karte, harte Regeln, was man für typische Aufgaben nicht lesen muss, wo die ADRs bzw. Entscheidungen liegen,
- [ ] mindestens 3 Punkte aus eurer Ü1-Liste darin stehen (oder bewusst woanders hin sortiert sind),
- [ ] `.claude/skills/spec/SKILL.md` existiert, mit Frontmatter (`name`, `description`), Schritten und der Ausgabe `specs/<slug>.md`,
- [ ] `/spec` in einer **neuen Session** auf eurem Ticket gelaufen ist und eine Datei unter `specs/` geschrieben hat,
- [ ] `AGENTS.md` und Skill committet sind (die Spec noch nicht).

**Tipp:** Den Skill vom Agenten schreiben lassen ist erlaubt. Aber ihr müsst jede Zeile verstehen und erklären können. Was ihr nicht erklären könnt, fliegt raus.

## Zeitplan

| Min. | Was |
|---|---|
| 0-10 | Blatt lesen, Branch anlegen, Ü1-Liste sortieren: Was gehört in `AGENTS.md`, was nicht? |
| 10-30 | `AGENTS.md` schreiben |
| 30-45 | `spec`-Skill schreiben |
| 45-60 | Neue Session, `/spec` auf dem Ticket, Rückfragen beantworten, Spec lesen |
| 60-66 | Im Raum vergleichen: `AGENTS.md` nebeneinander, Specs kurz zeigen |
| 66-70 | Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Tipp: Zur Halbzeit (nach ca. 35 Minuten) kurz aufstehen, strecken, Wasser holen. Laufende Agenten laufen weiter. Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Weg A: euer Repo

1. Eigenen Branch anlegen, nach eurem Schema:

   ```bash
   git switch -c seminar/<KEY>-<slug>
   ```

2. `AGENTS.md` anlegen. Gibt es schon eine, kürzt und ergänzt ihr sie, statt sie zu ersetzen. Sonst nehmt das Gerüst aus der Vorlage (Pfad zu eurem Clone anpassen):

   ```bash
   cp ../rheinwerk-starter-skills/AGENTS.md.template AGENTS.md
   ```

   Füllt nur, was der Agent nicht selbst findet: Gate-Befehle, Architektur-Karte (ein Ordner pro Zeile, was dort liegt und was nicht), harte Regeln aus eurer Ü1-Liste, wo ADRs bzw. Entscheidungen liegen, und was er für typische Aufgaben nicht lesen muss. Löscht jede `<ANPASSEN>`-Zeile, die ihr nicht braucht.
3. Ihr nutzt Claude Code und habt schon eine `CLAUDE.md` (oder `.claude/CLAUDE.md`, `CLAUDE.local.md`), oder eure Version ist älter als 2.1.277? Dann schreibt in die `CLAUDE.md` die Zeile `@AGENTS.md`, sonst lädt Claude Code die neue Datei nicht.
4. Skill anlegen: `mkdir -p .claude/skills/spec` und `SKILL.md` schreiben (Gerüst in Hilfe 2).
5. Neue Session, Skill aufrufen. Das Ticket gebt ihr als Text mit. Liegt es als Datei vor (`tickets/<KEY>.md`, siehe Ü0), schreibt ihr den Pfad dazu:

   ```text
   /spec <Ticket-Titel>. <Beschreibung und Akzeptanzkriterien einfügen>
   ```

   ```text
   /spec Ticket steht in tickets/<KEY>.md
   ```

6. Spec lesen. Dann committen, die Spec bleibt draußen:

   ```bash
   git add AGENTS.md .claude/skills
   git commit -m "feat(skills): add AGENTS.md and a minimal spec skill"
   ```

   Habt ihr `CLAUDE.md` geändert, nehmt sie vorher mit `git add CLAUDE.md` dazu. Die Spec aus diesem Lauf legt ihr zur Seite (z. B. `mkdir -p ../spec-v1 && mv specs/* ../spec-v1/`), ihr vergleicht sie in Ü3 mit der v2.

**Vertraulichkeit:** Im Raum zeigt ihr `AGENTS.md` nur, wenn das geht. Sonst die Struktur (Überschriften, Anzahl Regeln) und den Skill.

## Weg B: Demo-Fork

1. Arbeits-Branch für beide Tage anlegen (im Fork-Ordner `habit-tracker-demo`):

   ```bash
   git fetch origin
   git switch --no-track -c seminar/kategorien origin/main
   echo ".claude/settings.local.json" >> .git/info/exclude
   ```

   Die zweite Zeile sorgt dafür, dass eure persönliche Rechte-Datei (Ü4) nie mitcommittet wird.
2. `AGENTS.md` im Repo-Root schreiben, aus eurer Ü1-Liste. Englisch oder Deutsch, egal. Gates im Demo-Repo:

   ```bash
   npm run lint && npm run typecheck && npm test  # ~20 s
   PORT=3110 E2E_PORT=3110 npm run test:e2e  # ~45 s
   ```

3. Skill anlegen: `mkdir -p .claude/skills/spec`, dann `.claude/skills/spec/SKILL.md` schreiben (Gerüst in Hilfe 2).
4. Neue Session. Das Issue im Terminal anzeigen und den Text in den Aufruf kopieren:

   ```bash
   gh issue view 1
   ```

   ```text
   /spec Issue #1 Kategorien für Habits mit Filter.
   <Beschreibung und Akzeptanzkriterien aus gh issue view 1 einfügen>
   ```

5. Rückfragen beantworten (Vorschlag: feste Liste von Kategorien), Spec unter `specs/` lesen.
6. `AGENTS.md` und Skill committen. Die v1-Spec legt ihr neben das Repo, ihr vergleicht sie in Ü3 mit der v2:

   ```bash
   git add AGENTS.md .claude/skills
   git commit -m "feat(skills): add AGENTS.md and a minimal spec skill"
   mkdir -p ../spec-v1 && mv specs/* ../spec-v1/
   ```

## Pro Tool

| Tool | Kontext-Datei | Skill aufrufen | Neue Session |
|---|---|---|---|
| Claude Code | ab 2.1.277: liest `AGENTS.md`, wenn es keine `CLAUDE.md` gibt; sonst oder bei älterer Version `@AGENTS.md` in die `CLAUDE.md` | `/spec …`, das Autocomplete zeigt eure `description` | `/clear` oder `claude` neu starten |
| Codex | liest `AGENTS.md` | Skill spiegeln (Block unten), dann `$spec …` oder über `/skills` | `/new` |
| Cursor | liest `AGENTS.md` | liest `.claude/skills/`, im Agent-Chat `/spec …` | neuer Chat |
| Copilot | liest `AGENTS.md` | CLI liest `.claude/skills/`, `/skills reload`, falls er fehlt. VS Code: fehlt `/spec`, nach `.github/skills/` spiegeln (Block unten) | neuer Chat, CLI `/clear` |

Codex: spiegeln und die `$ARGUMENTS`-Zeile ergänzen, dann Codex neu starten, falls der Skill nicht in `/skills` steht:

```bash
mkdir -p .agents && cp -R .claude/skills .agents/
```

In `.agents/skills/spec/SKILL.md` unter die Zeile mit `$ARGUMENTS`: `(In Codex, or if this line shows $ARGUMENTS literally, use the text the user gave.)`. Committet `.agents/` mit.

Copilot in VS Code: Laut Doku ist für den Copilot-Harness `.github/skills/` der Projektordner. Zeigt der Chat `/spec` nicht, spiegeln und neuen Chat öffnen. Nach jeder Skill-Änderung erneut spiegeln und `.github/skills/` mitcommitten:

```bash
mkdir -p .github && cp -R .claude/skills .github/
```

Prüfen, ob die Kontext-Datei geladen ist (alle Tools): neue Session, `Welche Gates gelten in diesem Repo? Antworte nur aus dem geladenen Kontext, lies keine Dateien.`

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Die Kontext-Datei wird bei **jeder** Nachricht mitgeschickt und kostet Platz im Context Window. Nur was für fast jede Aufgabe gilt und was der Agent nicht selbst findet. Kein Inhalt von `package.json`, keine Dateilisten.
- Eine harte Regel ist prüfbar formuliert: „Jede Änderung an `app/types/app-data.ts` braucht ein neues ADR“, nicht „Achte auf das Schema“.
- „Was man nicht lesen muss“ spart am meisten: z. B. „UI-Features brauchen die Speicherschicht nicht“.
- Der Skill sagt **was** und **wann** in der `description`. Der Body ist der Ablauf in Schritten. „You plan, you do not build“ verhindert, dass er schon Code schreibt.

</details>

<details>
<summary>Hilfe 2: Gerüste zum Kopieren</summary>

`AGENTS.md` (ersetzt alles in spitzen Klammern):

````markdown
# AGENTS.md

<Ein Satz: Produkt und Stack.>

## Gates (all green before a commit)
```bash
<lint> && <typecheck> && <unit tests>  # ~xx s
<e2e mit festem Port>  # ~xx s
```

## Architecture map
- `<ordner>/` - <was dort liegt>, <was dort nicht hingehört>
- `specs/` - feature specs and verification reports

## Hard rules
- <Regel aus Ü1, prüfbar formuliert, mit Datei bzw. ADR>
- Never weaken, skip or delete a test to get a gate green.

## You do not need to read
- <Ordner, die für typische Features egal sind>

## ADRs
Decisions live in `<docs/adr/>`. Read the matching ADR before you touch <Bereiche>.
````

`.claude/skills/spec/SKILL.md`:

````markdown
---
name: spec
description: Plan a feature as a spec in specs/<slug>.md before any code is written.
argument-hint: "[task description]"
---

# Spec

Write a specification for: **$ARGUMENTS**

You plan, you do not build. Write no code and change no file except the spec.

1. If the argument is empty, ask what to specify and stop.
2. Read `AGENTS.md` and the files it names for this kind of task.
3. Ask the user 3 to 5 questions that change scope, data or UX. Give 2 to 3
   options each, recommended option first. Wait for the answers.
4. Pick a short kebab-case slug and write `specs/<slug>.md`:
   - `# <Title>`
   - `## Context` (2 to 4 sentences)
   - `## Decisions` (table: question, decision)
   - `## Requirements`
   - `## Acceptance criteria` (each one testable: `- [ ] AC1: …`)
   - `## Tasks` (small, ordered, files named)
   - `## Out of scope`
5. Show the path and a five-line summary. Then stop.
````

Den Agenten schreiben lassen:

```text
Schreib mir einen minimalen Skill unter .claude/skills/spec/SKILL.md
im Agent-Skills-Format (Frontmatter mit name und description).
Er soll aus einer Aufgabe eine Spec in specs/<slug>.md machen:
AGENTS.md lesen, 3 bis 5 Rückfragen mit Optionen stellen,
dann Context, Decisions, Requirements, Acceptance criteria, Tasks,
Out of scope schreiben und anhalten.
Kein Code. Höchstens 40 Zeilen. Erkläre mir danach jede Zeile in einem Satz.
```

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

Minimaler Skill (Stufe 1) und die `AGENTS.md` aus Stufe 2:

```bash
git show origin/stufe/01-spec-starter:.claude/skills/spec/SKILL.md
git show origin/stufe/02-spec-voll:AGENTS.md
```

Auffällig an der Muster-`AGENTS.md`: 36 Zeilen, die Regel „Schema changes are never silent“ mit ADR-Nummern, „UI features do not need the storage layer“, „Never use port 3000“.

Weg A: das Gerüst `AGENTS.md.template` in der Vorlage. Den vollen Spec-Skill baut ihr erst in Ü3.

</details>

## Rückfall

Weg B: Skill aus Stufe 1 und `AGENTS.md` aus Stufe 2 holen, committen, weiter mit Ü3. Auf `seminar/kategorien` (falls es den Branch noch nicht gibt: Schritt 1 von Weg B):

```bash
git checkout origin/stufe/01-spec-starter -- .claude/skills/spec
git checkout origin/stufe/02-spec-voll -- AGENTS.md
git commit -m "feat(skills): add AGENTS.md and a minimal spec skill"
```

Codex danach spiegeln bzw. Copilot in VS Code, falls nötig (nur den Kasten für euer Tool):

```bash
# Codex
mkdir -p .agents && cp -R .claude/skills .agents/
```

```bash
# Copilot in VS Code
mkdir -p .github && cp -R .claude/skills .github/
```

Weg A: Minimum für Ü3 ist eine `AGENTS.md` mit euren Gate-Befehlen und drei harten Regeln. Den Skill könnt ihr in Ü3 direkt aus der Vorlage übernehmen.

## Bonus für Schnelle

- Den Skill zweimal auf dasselbe Ticket loslassen, einmal mit und einmal ohne `AGENTS.md` (Datei kurz umbenennen). Was ändert sich an Rückfragen und Spec?
- `AGENTS.md` kürzen: Welche Zeile könnt ihr streichen, ohne dass der Agent etwas falsch macht?
- Die `description` des Skills umformulieren und prüfen, ob der Agent ihn bei „Plane mir Feature X“ von selbst vorschlägt.

## Für den Debrief

Leitfrage: **Was steht in eurer `AGENTS.md`, und was bewusst nicht?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): eure wichtigste harte Regel (eine Zeile) und eine Frage.
- Im Plenum zeigen zwei Räume ihre `AGENTS.md`. Der Kursleiter zeigt danach den Diff von Stufe 1 und die `AGENTS.md` aus Stufe 2.
